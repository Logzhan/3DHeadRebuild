#ifndef  _3D_FACE_API_
#define  _3D_FACE_API_

#include "GlobalConfig.h"

//#ifdef __cplusplus   
//extern "C" {   
//#endif   
	/* Loading the 3D face model by file name                      */
    __declspec(dllexport) bool Load3dfaceModel(char *FileName);

	/* Get the MorphableModel, you must call the Load3dfaceModel()
	   firstly and then call  this function.                       */
	__declspec(dllexport) MorphableModel GetMorphableModel(void);
  

//#ifdef __cplusplus   
//}   
//#endif 



#endif